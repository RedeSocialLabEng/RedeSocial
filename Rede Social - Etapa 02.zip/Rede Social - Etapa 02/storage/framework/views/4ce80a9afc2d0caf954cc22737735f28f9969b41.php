<?php $__env->startSection('content'); ?>
<center>
    <div class="bg-light p-5 rounded">
        <?php if(auth()->guard()->check()): ?>
        Bem vindo   <?php echo e(Auth::user()->username); ?>

        <h1>Publicar</h1>

        <form action = "/create" method = "post" style="width:100%;" enctype="multipart/form-data">
        <input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>"><input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
        <label class="form-group">Mensagem:</label>
        <input type="text" class="form-control" placeholder="Escreva sua mensagem aqui." name="msg"><br>

        <label class="form-group">Imagem:</label>
        <input type="file" name="image" class="form-control"><br>
        <button type="submit"  value = "Enviar" class="btn btn-primary w-100">Publicar</button>
        </form>















<br>
        <h1>Timeline </h1>
        <p class="lead">Veja as publicações a seguir.</p>
        <table>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <tbody style="padding:25px">
        <tr>
        </tr>
        <tr>
        <?php if($post->img !=""): ?>    
            <td style="padding:10px; background:#fff"><img src="images/<?php echo e($post->img); ?>" style="max-width:350px;"></td>
        <?php endif; ?>
        </tr>
        <tr>
            <td   style="padding-bottom:35px">@ <?php echo e($post->user); ?><br>
            <?php echo e($post->texto); ?></td>
        </tr>
        <tr>
            <td style="border-bottom:1px solid #ccc;"></td>
        </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
<br>
        <h1>Usuários</h1>
        <table>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <tbody>
        <tr>
            <td><?php echo e($user->email); ?></td>
        </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <?php endif; ?>

        <?php if(auth()->guard()->guest()): ?>
        <h1>Rede Social</h1>
        <p class="lead">Faça o login para continuar.</p>
        <?php endif; ?>
    </div>

</center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\Rede Social - Etapa 02\resources\views/home/index.blade.php ENDPATH**/ ?>