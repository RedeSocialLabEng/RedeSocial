@extends('layouts.app-master')

@section('content')
<center>
    <div class="bg-light p-5 rounded">
        @auth
        Bem vindo   {{ Auth::user()->username }}
        <h1>Publicar</h1>

        <form action = "/create" method = "post" style="width:100%;" enctype="multipart/form-data">
        <input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>"><input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
        <label class="form-group">Mensagem:</label>
        <input type="text" class="form-control" placeholder="Escreva sua mensagem aqui." name="msg"><br>

        <label class="form-group">Imagem:</label>
        <input type="file" name="image" class="form-control"><br>
        <button type="submit"  value = "Enviar" class="btn btn-primary w-100">Publicar</button>
        </form>















<br>
        <h1>Timeline </h1>
        <p class="lead">Veja as publicações a seguir.</p>
        <table>
        @foreach ($posts as $post) 
        <tbody style="padding:25px">
        <tr>
        </tr>
        <tr>
        @if ($post->img !="")    
            <td style="padding:10px; background:#fff"><img src="images/{{ $post->img }}" style="max-width:350px;"></td>
        @endif
        </tr>
        <tr>
            <td   style="padding-bottom:35px">@ {{ $post->user }}<br>
            {{ $post->texto }}</td>
        </tr>
        <tr>
            <td style="border-bottom:1px solid #ccc;"></td>
        </tr>
        </tbody>
        @endforeach
        </table>
<br>
        <h1>Usuários</h1>
        <table>
        @foreach ($users as $user) 
        <tbody>
        <tr>
            <td>{{ $user->email }}</td>
        </tr>
        </tbody>
        @endforeach
        </table>
        @endauth

        @guest
        <h1>Rede Social</h1>
        <p class="lead">Faça o login para continuar.</p>
        @endguest
    </div>

</center>
@endsection
