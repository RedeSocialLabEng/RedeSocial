<?php
namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Auth;
//use App\Http\Requests;
use App\Http\Controllers\Controller;

class PostController extends Controller
{
public function insertform(){
//return view('home.index');
        }
public function insert(Request $request){
$imageName="";

        if (isset($request->image)) {
    $request->validate([
        'image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
    ]);

    $imageName = time().'.'.$request->image->extension();  
 
    $request->image->move(public_path('images'), $imageName); }
    $userrnamm=Auth::user()->username;
$msg = $request->input('msg');
$data=array("texto"=>$msg,'img'=>$imageName,'user'=>$userrnamm);
DB::table('posts')->insert($data);
return back();
        }
}


/*
public function imageUpload()
{
    return view('imageUpload');
}


public function imageUploadPost(Request $request)
{
    $request->validate([
        'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
    ]);

    $imageName = time().'.'.$request->image->extension();  
 
    $request->image->move(public_path('images'), $imageName);

    /* Store $imageName name in DATABASE from HERE 

    return back()
        ->with('success','You have successfully upload image.')
        ->with('image',$imageName); 
}*/
